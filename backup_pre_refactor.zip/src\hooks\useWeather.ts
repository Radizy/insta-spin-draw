import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface WeatherData {
    temp: number;
    description: string;
    icon: string; // Ex: '01d', '02n'
    city: string;
}

export function useWeather(city: string | null | undefined) {
    const [weather, setWeather] = useState<WeatherData | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!city) {
            setWeather(null);
            setError(null);
            return;
        }

        const fetchWeatherCache = async () => {
            setLoading(true);
            setError(null);

            try {
                const { data, error: sbError } = await supabase
                    .from('unidades')
                    .select('clima_cache, clima_updated_at')
                    .ilike('cidade_clima', city)
                    .limit(1)
                    .maybeSingle();

                if (sbError) {
                    throw new Error(sbError.message);
                }

                let cachedData = data?.clima_cache as any;
                let lastUpdated = data?.clima_updated_at ? new Date(data.clima_updated_at).getTime() : 0;
                const now = new Date().getTime();
                const twentyMinutes = 20 * 60 * 1000;

                const needsUpdate = !cachedData || (now - lastUpdated > twentyMinutes);

                if (needsUpdate) {
                    console.log(`Clima desatualizado ou vazio para ${city}. Buscando direto na OpenWeather...`);

                    const apiKey = import.meta.env.VITE_OPENWEATHER_API_KEY;
                    if (!apiKey) {
                        throw new Error('Chave VITE_OPENWEATHER_API_KEY não configurada no painel. Avise o suporte.');
                    }

                    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
                        city
                    )}&units=metric&appid=${apiKey}&lang=pt_br`;

                    const response = await fetch(url);
                    if (!response.ok) {
                        throw new Error(`Falha na OpenWeather: ${response.statusText}`);
                    }

                    const weatherData = await response.json();

                    // Sucesso! Atualiza o banco para que as outras TVs e recarregamentos usem o novo cache
                    await supabase
                        .from('unidades')
                        .update({
                            clima_cache: weatherData,
                            clima_updated_at: new Date().toISOString()
                        })
                        .ilike('cidade_clima', city);

                    cachedData = weatherData;
                }

                setWeather({
                    temp: Math.round(cachedData.main.temp),
                    description: cachedData.weather[0].description,
                    icon: cachedData.weather[0].icon,
                    city: cachedData.name,
                });
            } catch (err) {
                console.error('Erro ao processar Clima:', err);
                setError(err instanceof Error ? err.message : 'Erro desconhecido ao processar o clima');
                setWeather(null);
            } finally {
                setLoading(false);
            }
        };

        fetchWeatherCache();

        // Ouve atualizações em tempo real na tabela de unidades para a coluna de clima
        const channel = supabase
            .channel('public:unidades:clima_cache')
            .on(
                'postgres_changes',
                {
                    event: 'UPDATE',
                    schema: 'public',
                    table: 'unidades',
                    filter: `cidade_clima=ilike.${city}`
                },
                (payload) => {
                    const newData = payload.new as any;
                    if (newData.clima_cache) {
                        const cachedData = newData.clima_cache;
                        setWeather({
                            temp: Math.round(cachedData.main.temp),
                            description: cachedData.weather[0].description,
                            icon: cachedData.weather[0].icon,
                            city: cachedData.name,
                        });
                    }
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [city]);

    return { weather, loading, error };
}
